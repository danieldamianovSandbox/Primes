﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int Number = int.Parse(Console.ReadLine());
            int num = 0;
            for (int i = 0; i < Number; i++)
            {
                bool isSimple = true;
                int n = int.Parse(Console.ReadLine());
                for (int j = 2; j < n; j++)
                {
                    if (n % j == 0)
                    {
                        isSimple = false;
                    }
                }
                if (isSimple == true)
                {
                    num++;
                }
            }
            Console.WriteLine(num);
        }
    }
}
